void collatz(int n) {

    /*Detección de errores por valores menores a 1*/
    if (n <= 0){
        cerr << "/* Valor menor a 1 no permitido */" << endl;

    /*Caso Base*/
    }else if (n == 1){
        cout << " 1" << endl;

    /*Caso recusrsivo*/
    } else {
        cout << " " << n;
        if (n%2 == 0){
            collatz(n/2);
        } else {
            collatz((3*n)+1);
        }
    }
}
