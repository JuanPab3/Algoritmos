void router_speedup (vector<string> &rooms, vector<int> &numcls, int range) {
    if (rooms.size() != numcls.size()) cerr << "/* Both vectors must have the same size */" << endl;

    int max;

    int zs = numcls.size()-1;
    for (int i = 0; i <= zs; i++) {
        max = i;
        if (numcls[i] >= range){
            for (int j = i; j <= zs; j++) {
                if (numcls[max] < numcls[j])
                max = j;
            }
            swap(numcls[i],numcls[max]);
            swap(rooms[i],rooms[max]);
        }
    }

}
